import numpy as np
from flask import Flask, request, jsonify, render_template
from joblib import load
from sklearn import preprocessing
from sklearn.preprocessing import StandardScaler
from tensorflow.keras.models import load_model
from tensorflow.keras.models import Sequential 

categorical = Sequential()

app = Flask(__name__)

model = load_model("irismodelnew.h5")
#sc=load("transform1.save")
@app.route('/')
def home():
    return render_template('index2.html')

@app.route('/y_predict',methods=['POST'])
def y_predict():


    sl = request.form['sl']
    sw = request.form['sw']
    pl = request.form['pl']
    pw = request.form['pw']
    
    total = [[sl,sw,pl,pw]]
    ispecies = ['Setosa','Versicolor', 'Virginica']
    prediction= preprocessing.StandardScaler().fit(total)
      
    pred = ispecies[np.argmax(prediction)]

    return render_template('index2.html', prediction_text='Result: {}'.format(pred))

if __name__ == "__main__":
    app.run(port=8086,debug=False)
